import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { registerServiceWorker } from "./utils/notifications";
import { oneSignalService } from "./services/oneSignalService";
import { ToastProvider } from "./components/ui/Toast";

registerServiceWorker();
oneSignalService.init().catch(() => {});

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    {/* ✅ ToastProvider envuelve toda la app para usar useToast() en cualquier componente */}
    <ToastProvider>
      <App />
    </ToastProvider>
  </React.StrictMode>
);
