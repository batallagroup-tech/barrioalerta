import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Search, MessageSquare } from 'lucide-react';

interface EmptyStateProps {
  type: 'feed' | 'feed-filtered' | 'chat' | 'map';
}

const CONFIG = {
  feed: {
    Icon: ShieldCheck,
    iconColor: 'text-green-500',
    iconBg: 'bg-green-500/10',
    title: 'Tu barrio está tranquilo',
    subtitle: 'No hay alertas recientes en tu zona. Amplía el radio de búsqueda si quieres ver más.',
  },
  'feed-filtered': {
    Icon: Search,
    iconColor: 'text-slate-400',
    iconBg: 'bg-slate-800',
    title: 'Sin resultados',
    subtitle: 'Ningún incidente coincide con tu búsqueda o filtro actual. Intenta con otra categoría.',
  },
  chat: {
    Icon: MessageSquare,
    iconColor: 'text-blue-400',
    iconBg: 'bg-blue-500/10',
    title: 'Sin mensajes aún',
    subtitle: 'Sé el primero en escribir en el chat comunitario.',
  },
  map: {
    Icon: ShieldCheck,
    iconColor: 'text-green-500',
    iconBg: 'bg-green-500/10',
    title: 'Zona despejada',
    subtitle: 'No hay incidentes activos en el mapa de tu zona.',
  },
} as const;

export const EmptyState: React.FC<EmptyStateProps> = ({ type }) => {
  const { Icon, iconColor, iconBg, title, subtitle } = CONFIG[type];

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      className="flex flex-col items-center justify-center py-24 px-8 text-center"
    >
      <div className={`w-20 h-20 ${iconBg} rounded-full flex items-center justify-center mb-5`}>
        <Icon size={36} className={iconColor} strokeWidth={1.5} />
      </div>
      <h3 className="font-black text-white uppercase tracking-widest text-sm mb-2">
        {title}
      </h3>
      <p className="text-slate-500 text-xs font-medium leading-relaxed max-w-[240px]">
        {subtitle}
      </p>
    </motion.div>
  );
};
