// Este hook ya expone `loading`. Solo asegúrate de pasarlo a IncidentFeed en DashboardView.
// En DashboardView.tsx, la línea:
//   const { incidents } = useIncidents();
// cámbiala a:
//   const { incidents, loading: incidentsLoading } = useIncidents();
//
// Y en el JSX donde renderizas <IncidentFeed ...>, añade:
//   loading={incidentsLoading}
//
// El hook en sí no necesita cambios — ya tiene el flag correcto.

import { useState, useEffect } from 'react';
import { Incident } from '../types';
import { incidentService } from '../services/supabase/incidentService';

export function useIncidents() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const unsub = incidentService.subscribeToIncidents((data) => {
      setIncidents(data);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  return { incidents, loading };
}
