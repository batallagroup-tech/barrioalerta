import React, { useState, useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from "react-leaflet";
import L from "leaflet";
import { Plus, Minus } from "lucide-react";
import { Incident, Location as GeoLocation } from "../../types/incident.types";
import { CATEGORY_CONFIG } from "../../constants/categories";

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

function createEmojiIcon(emoji: string) {
  return L.divIcon({
    html: `<div style="font-size:22px;line-height:1;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.5))">${emoji}</div>`,
    className: "",
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
}

// ✅ FIX: MapController separado en dos hooks independientes.
// - El zoom externo (prop) se aplica SOLO en el montaje inicial, no en
//   cada re-render. Así el usuario puede hacer pinch/zoom libremente.
// - El center se actualiza cada vez que el GPS cambia, pero SIN tocar el zoom.
function MapController({
  center,
  initialZoom,
  externalZoom,
}: {
  center: [number, number];
  initialZoom: number;
  externalZoom: number | null; // null = no forzar zoom
}) {
  const map = useMap();
  const mounted = useRef(false);
  const prevCenter = useRef(center);

  // Solo en el primer render: aplicar zoom inicial
  useEffect(() => {
    if (!mounted.current) {
      map.setView(center, initialZoom, { animate: false });
      mounted.current = true;
    }
  }, []); // eslint-disable-line

  // Cuando el center cambia (GPS actualizado): mover sin cambiar zoom
  useEffect(() => {
    const [prevLat, prevLng] = prevCenter.current;
    const [lat, lng] = center;
    // Evitar setView si el cambio es insignificante (< ~10 metros) para no
    // interrumpir al usuario con micro-movimientos del GPS
    const delta = Math.abs(lat - prevLat) + Math.abs(lng - prevLng);
    if (delta > 0.0001) {
      map.panTo(center, { animate: true });
      prevCenter.current = center;
    }
  }, [center[0], center[1]]); // eslint-disable-line

  // Si se pasa un zoom externo explícito (botones +/-), aplicarlo
  useEffect(() => {
    if (externalZoom !== null) {
      map.setZoom(externalZoom, { animate: true });
    }
  }, [externalZoom]); // eslint-disable-line

  return null;
}

type MapType = "dark" | "streets" | "satellite" | "topo";

const MAP_TYPES: { id: MapType; label: string }[] = [
  { id: "dark",      label: "Noche" },
  { id: "streets",   label: "Mapa" },
  { id: "satellite", label: "Satélite" },
  { id: "topo",      label: "Topo" },
];

interface MapViewProps {
  incidents: Incident[];
  userLocation: GeoLocation;
  radiusKm: number;
  onSelectIncident?: (incident: Incident) => void;
  interactive?: boolean;
}

export const MapView: React.FC<MapViewProps> = ({
  incidents,
  userLocation,
  radiusKm,
  onSelectIncident,
  interactive = true,
}) => {
  const [mapType, setMapType] = useState<MapType>("dark");
  // ✅ zoom externo: null = sin forzar; número = forzar al MapController
  const [externalZoom, setExternalZoom] = useState<number | null>(null);
  const INITIAL_ZOOM = 14;
  const center: [number, number] = [userLocation.lat, userLocation.lng];
  const key = import.meta.env.VITE_MAPTILER_KEY;

  const getTileUrl = (type: MapType) => {
    switch (type) {
      case "dark":      return `https://api.maptiler.com/maps/streets-dark/256/{z}/{x}/{y}.png?key=${key}`;
      case "streets":   return `https://api.maptiler.com/maps/streets/256/{z}/{x}/{y}.png?key=${key}`;
      case "satellite": return `https://api.maptiler.com/maps/satellite/256/{z}/{x}/{y}.jpg?key=${key}`;
      case "topo":      return `https://api.maptiler.com/maps/topo-v2/256/{z}/{x}/{y}.png?key=${key}`;
    }
  };

  const handleZoomIn = () =>
    setExternalZoom(prev => Math.min((prev ?? INITIAL_ZOOM) + 1, 18));
  const handleZoomOut = () =>
    setExternalZoom(prev => Math.max((prev ?? INITIAL_ZOOM) - 1, 3));

  return (
    <div style={{ position: "relative", height: "calc(100vh - 140px)", width: "100%" }}>
      <style>{`.leaflet-pane { z-index: 1 !important; } .leaflet-top, .leaflet-bottom { z-index: 2 !important; }`}</style>
      <MapContainer
        center={center}
        zoom={INITIAL_ZOOM}
        style={{ height: "100%", width: "100%", minHeight: 400, background: "#0f172a" }}
        zoomControl={false}
        dragging={interactive}
        scrollWheelZoom={interactive}
        doubleClickZoom={interactive}
      >
        <MapController
          center={center}
          initialZoom={INITIAL_ZOOM}
          externalZoom={externalZoom}
        />
        <TileLayer
          url={getTileUrl(mapType)}
          attribution='&copy; <a href="https://www.maptiler.com/">MapTiler</a>'
          tileSize={256}
        />
        <Circle
          center={center}
          radius={radiusKm * 1000}
          pathOptions={{ color: "#3b82f6", fillColor: "#3b82f6", fillOpacity: 0.05, weight: 1 }}
        />
        <Marker
          position={center}
          icon={L.divIcon({
            html: `<div style="width:26px;height:26px;background:#2563eb;border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.5)"></div>`,
            className: "",
            iconSize: [26, 26],
            iconAnchor: [13, 13],
          })}
        >
          <Popup>Tu ubicación</Popup>
        </Marker>
        {incidents.map((incident) => {
          const cfg = CATEGORY_CONFIG[incident.category] ?? CATEGORY_CONFIG.Other;
          return (
            <Marker
              key={incident.id}
              position={[incident.location.lat, incident.location.lng]}
              icon={createEmojiIcon(cfg.emoji)}
              eventHandlers={{ click: () => onSelectIncident?.(incident) }}
            >
              <Popup>
                <strong>{incident.title}</strong><br />
                <span style={{ fontSize: 12 }}>{incident.description}</span>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>

      {interactive && (
        <>
          <div className="absolute top-6 left-6 z-[5] flex flex-col gap-1 bg-slate-900/80 backdrop-blur-xl border border-white/10 p-1 rounded-2xl shadow-2xl">
            <button onClick={handleZoomIn} className="p-3 text-slate-400 hover:text-white rounded-xl" aria-label="Acercar">
              <Plus size={20} />
            </button>
            <button onClick={handleZoomOut} className="p-3 text-slate-400 hover:text-white rounded-xl" aria-label="Alejar">
              <Minus size={20} />
            </button>
          </div>

          <div className="absolute top-6 right-6 z-[5]">
            <div className="bg-slate-900/80 backdrop-blur-xl border border-white/10 p-1 rounded-2xl shadow-2xl flex gap-1">
              {MAP_TYPES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setMapType(t.id)}
                  className={`px-3 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-colors ${
                    mapType === t.id ? "bg-slate-800 text-white" : "text-slate-500 hover:text-white"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
