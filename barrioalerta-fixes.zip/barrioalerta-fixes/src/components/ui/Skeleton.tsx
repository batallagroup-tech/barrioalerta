import React from 'react';

// Animación de shimmer via Tailwind animate-pulse
const Shimmer: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`bg-slate-800 rounded-xl animate-pulse ${className}`} />
);

export const IncidentCardSkeleton: React.FC = () => (
  <div className="bg-slate-900 rounded-[2rem] border border-slate-800 overflow-hidden">
    {/* Imagen */}
    <div className="aspect-[16/9] bg-slate-800 animate-pulse relative">
      {/* Badge */}
      <div className="absolute top-4 left-4">
        <Shimmer className="w-24 h-6 rounded-full" />
      </div>
      {/* Usuario */}
      <div className="absolute bottom-4 left-6 right-6 space-y-2">
        <div className="flex items-center gap-2">
          <Shimmer className="w-5 h-5 rounded-md" />
          <Shimmer className="w-20 h-3" />
        </div>
        <Shimmer className="w-3/4 h-5" />
        <Shimmer className="w-1/2 h-3" />
      </div>
    </div>

    {/* Contenido */}
    <div className="px-6 py-5 space-y-3">
      <Shimmer className="w-full h-3" />
      <Shimmer className="w-2/3 h-3" />
      <div className="flex justify-between pt-2 border-t border-slate-800/50">
        <Shimmer className="w-24 h-3" />
        <Shimmer className="w-16 h-3" />
      </div>
    </div>
  </div>
);

export const FeedSkeleton: React.FC = () => (
  <div className="space-y-6">
    {[1, 2, 3].map(i => (
      <IncidentCardSkeleton key={i} />
    ))}
  </div>
);
