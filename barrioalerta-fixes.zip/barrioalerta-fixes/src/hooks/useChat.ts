import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { chatService } from '../services/supabase/chatService';
import { ChatMessage, UserProfile } from '../types';

export function useChat(
  authenticated: boolean,
  currentUser: UserProfile | null,
  incidentId?: string
) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  // ✅ FIX: ref para el cleanup de la suscripción ACTUAL
  const unsubRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    // ─── Cleanup previo SIEMPRE antes de crear nueva suscripción ──────────────
    // Esto evita la race condition cuando incidentId cambia rápido:
    // el canal anterior se cierra antes de abrir el nuevo.
    if (unsubRef.current) {
      unsubRef.current();
      unsubRef.current = null;
    }

    // Sin autenticación: no suscribir nada
    if (!authenticated) {
      setMessages([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    // Limpiar mensajes al cambiar de canal para evitar que mensajes del canal
    // anterior aparezcan brevemente en el nuevo
    setMessages([]);

    if (incidentId) {
      // ─── Chat de incidente específico ──────────────────────────────────────
      let cancelled = false; // guard para async dentro del efecto

      supabase
        .from('incident_messages')
        .select('*')
        .eq('incident_id', incidentId)
        .order('created_at', { ascending: true })
        .limit(50)
        .then(({ data }) => {
          if (cancelled) return;
          if (data) {
            setMessages(data.map((r: any) => ({
              id: r.id,
              userId: r.user_id,
              userName: r.user_name,
              userPhoto: r.user_photo,
              text: r.text,
              timestamp: r.created_at,
              type: r.type ?? 'text',
              reactions: r.reactions ?? {},
            })));
          }
          setLoading(false);
        });

      // Canal con nombre único por incidentId + timestamp para evitar conflictos
      const channelName = `incident-chat-${incidentId}-${Date.now()}`;
      const channel = supabase
        .channel(channelName)
        .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'incident_messages',
          filter: `incident_id=eq.${incidentId}`,
        }, (payload) => {
          const r = payload.new as any;
          setMessages(prev => [...prev, {
            id: r.id,
            userId: r.user_id,
            userName: r.user_name,
            userPhoto: r.user_photo,
            text: r.text,
            timestamp: r.created_at,
            type: r.type ?? 'text',
            reactions: r.reactions ?? {},
          }]);
        })
        .subscribe();

      unsubRef.current = () => {
        cancelled = true;
        supabase.removeChannel(channel);
      };

    } else {
      // ─── Community chat ────────────────────────────────────────────────────
      const unsub = chatService.subscribeToCommunityChat((data) => {
        setMessages(data);
        setLoading(false);
      });
      unsubRef.current = unsub;
    }

    // Cleanup cuando el efecto se desmonta o las deps cambian
    return () => {
      if (unsubRef.current) {
        unsubRef.current();
        unsubRef.current = null;
      }
    };
  }, [authenticated, incidentId]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || !currentUser) return;
    if (incidentId) {
      await chatService.sendIncidentMessage(incidentId, text, currentUser);
    } else {
      await chatService.sendMessage(text, currentUser);
    }
  };

  const addReaction = async (msgId: string, emoji: string) => {
    if (!currentUser) return;
    await chatService.addReaction(msgId, emoji, currentUser, incidentId);
  };

  return { messages, setMessages, loading, sendMessage, addReaction };
}
